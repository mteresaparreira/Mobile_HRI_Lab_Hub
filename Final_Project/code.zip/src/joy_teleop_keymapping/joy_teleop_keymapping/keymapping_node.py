import time
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Joy
from geometry_msgs.msg import Twist


class TeleopTwistJoy(Node):
    def __init__(self):
        super().__init__('Teleop_Keymapping_node')
        self.joy_sub = self.create_subscription(Joy, '/joy', self.joyCallback, 10)
        self.twist_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.max_linear_speed = 0.1
        self.max_angular_speed = 0.1


    def joyCallback(self, msg):
        self.sendCommand(msg)

    def sendCommand(self, msg):
        t = Twist()
        # safety lock, press top left button
        if msg.buttons[4] == 1.0:
            t.linear.x = msg.axes[1]*self.max_linear_speed
            # use to represent angular velocity
            t.angular.z = (-1)*msg.axes[3]*self.max_angular_speed
            self.twist_pub.publish(t)
        else:
            t.linear.x = 0.0
            t.angular.z = 0.0
            self.twist_pub.publish(t)

        
        if msg.buttons[6] == 1.0:
            print ("maybe wiggling?")
            start = time.time() # get current time
            percent = 0.99
            while time.time() <= start + 1: # do the following command for 1 second
                t.linear.x = 0.0
                t.angular.z = percent*self.max_angular_speed
                self.twist_pub.publish(t)
                time.sleep(0.2) # good to pause a little bit in practice
            self.twist_pub.publish(t)
            start = time.time()
            while time.time() <= start + 1: # do the following command for 1 second
                t.linear.x = 0.0
                t.angular.z = -1*percent*self.max_angular_speed
                self.twist_pub.publish(t)
                time.sleep(0.2) # good to pause a little bit in practice

def main(args = None):
    rclpy.init(args=args)
    ttj = TeleopTwistJoy()
    rclpy.spin(ttj)
    rclpy.shutdown()


if __name__ == '__main__':
    main()
